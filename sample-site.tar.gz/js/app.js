let count = 0;
const el = document.getElementById('count');
function increment() { el.textContent = ++count; }
function decrement() { el.textContent = --count; }
document.getElementById('time').textContent = new Date().toISOString();
