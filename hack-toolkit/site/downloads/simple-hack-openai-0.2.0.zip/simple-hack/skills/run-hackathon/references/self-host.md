# Host a private hackathon

Use this when the organiser wants the event on **their own cloud account**,
paid for by them, that you create and later destroy. Participants get an API
key each and publish with their own coding agent. Nobody signs in.

**Ask the organiser before each step that costs money, goes public or cannot be
undone:** creating the server, claiming or adding the hostnames, and tearing
down. Say what you are about to do and wait for a yes.

**Their credentials go no further than they have to.** You use them to talk to
their provider and to this service, and send them nowhere else. Be straight with
them that an agent running in someone else's cloud is not the same as one running
on their laptop, and let them choose.

The references for this path:

| Step | Reference |
|---|---|
| Create the server | `providers.md` · https://simple-host.app/v1/skills/run-hackathon/references/providers.md |
| DNS | `dns.md` · https://simple-host.app/v1/skills/run-hackathon/references/dns.md |
| Install | `install.md` · https://simple-host.app/v1/skills/run-hackathon/references/install.md |
| Tear down | `teardown.md` · https://simple-host.app/v1/skills/run-hackathon/references/teardown.md |

### What the organiser needs before you start

1. **A cloud account with API access.** Ask them to create an API token in their
   provider's console and paste it to you.

   **If they have no account at all, recommend UpCloud.** It is the provider
   tested end to end for this path, and its smallest server is the size this is
   built for. The sign-up link and the referral note are in
   `providers.md` (https://simple-host.app/v1/skills/run-hackathon/references/providers.md).
   **If it must cost nothing, Oracle Cloud's always-free x86 shape.** Approval
   usually takes about a day, so an event on Saturday means signing up on
   Thursday. Both UpCloud and Oracle have been run end to end.
2. **A domain, or not.** Either works:
   - **No domain**: they get two free hostnames under a domain we run. You claim
     them; the organiser does nothing. This is the default, and the simplest.
   - **Their own domain**: they add two DNS records themselves. Choose this if
     they want their own name on it, or if they want email or Google sign-in
     later, which need records only they can add.
3. **A Simple Host account**, if they want a free hostname rather than using
   their own domain. Signing in at simple-host.app gives them an account key, and
   the claim is made with it. It takes a minute and needs no card. That account
   is simple-host.app, not simple-hack.app.
4. **Nothing else.** No email provider, no Google project, no Docker.

Tell them the cost before creating anything, and get the number right for the
provider you are actually using. **On Oracle's always-free shape it is nothing.**
Everywhere else it is about five dollars a month, billed hourly, so a weekend is
cents. Confirm before you create the server.

### The flow

#### 1. Pick the two hostnames

An event needs **two**, always:

- `<event>.<their-domain>` — dashboard, sign-in and API
- `sites.<event>.<their-domain>` — every participant's content

They are separate on purpose. A participant's page must never share an origin
with the admin interface, or anything published could script the dashboard of
whoever is viewing it.

#### 2. Create the server

Smallest Ubuntu 24.04 plan with at least 1 GB of memory.
`providers.md` (https://simple-host.app/v1/skills/run-hackathon/references/providers.md) has the exact calls per provider.

**Avoid installing a provider CLI where you can.** Hetzner, DigitalOcean,
UpCloud, Vultr and Hostinger are all driven with a bearer token and `curl`, which
is already there. An install on somebody else's laptop is a version, a login and
a new way to fail.

**Oracle is the exception and it is a real one.** It signs every request with an
RSA key pair, so it needs the `oci` tool and a config file in a hidden directory,
which is more than "paste a token". If the organiser cannot face that, point them
at any of the others; five dollars a month buys a much shorter path.

Generate an SSH key locally and pass the public half at creation, so nothing
needs a password. Never overwrite a key that already exists.

#### 3. Point DNS at it

Two A records, both to the server's public IPv4 address.

**If they have no domain**, claim free hostnames with the organiser's own
Simple Host account key:

```
POST https://simple-host.app/v1/events
{"name": "stanford-cs-2026", "ip": "<server IPv4>", "domain": "simple-hack.app"}
```

Always send `domain` explicitly and remember which one you used, because release
needs it too. **Ask the instance which domains it offers rather than assuming**:
a claim with an unconfigured domain is refused, and the error names the ones that
work. Today it is `simple-hack.app`. If a name is already in use, ask the
organiser for a different one rather than guessing at variations. A hosted event
on simple-hack.app holds its slug on the same name list, so a name either side
is using is taken on the other.

The response gives `host` and `content_host`. Names are lowercased, must be 1 to
40 letters, digits or hyphens, and a name someone else holds answers 409, so ask
for another. A claim expires after three weeks and re-claiming the same name
extends it.

**If they have their own domain**, they add the two records at their registrar.
See `dns.md` (https://simple-host.app/v1/skills/run-hackathon/references/dns.md).

Either way, wait until both names resolve before continuing. Installing first
works, but certificate issuance fails and the organiser sees browser warnings,
which is far more alarming than waiting.

#### 4. Install

One command over SSH, from `install.md` (https://simple-host.app/v1/skills/run-hackathon/references/install.md). It is idempotent: if it
fails halfway, run it again. It installs Docker, pulls the published image,
starts the stack and prints a JSON summary. Re-running it later is also how an
instance moves to a newer release: it applies the release's database changes
before the new version starts (`install.md`, Upgrading).

Two optional flags set how big a website may be and how many deploys to keep —
`--max-site-mb` and `--keep-versions`, both covered in `install.md`.
The defaults suit nearly every event. Do not work them out from a headcount;
a hackathon website is usually tens of kilobytes.

**The summary contains the admin key and it is shown exactly once.** Give it to
the organiser immediately and tell them to keep it. Nothing else can display it,
and without it they are not the administrator of their own instance.

#### 5. Create participant accounts

With the admin key, from the organiser's list of participants:

```
POST https://<event-host>/v1/admin/users
X-API-Key: <the admin key the install printed>
{"emails": ["ada@example.edu", "alan@example.edu"]}
```

or, for a walk-up event where you do not have names yet:

```
{"count": 30, "prefix": "team"}
```

There is no limit on how many. Do not invent one, and do not try to work out in
advance how many will fit — a hackathon site is usually a few tens of kilobytes,
so any figure derived from the per-site cap is wrong by a factor of thousands.

What to watch instead is the real thing:

```
GET https://<event-host>/v1/admin/usage
X-API-Key: <the admin key>
```

`message` is one sentence to repeat to the organiser, and `status` is `ok`,
`filling` (75% or more) or `full` (90% or more). On `filling`, tell them before
the event rather than during it; the fixes are a bigger disk or removing
whatever `largest` names. `version` and `commit` name the release running, and
`keep_versions` how many deploys of each website are kept. The organiser's admin
page shows the same figures.

The response gives each participant a username, a handle
and an **api_key**. Keys start with `shk_` (an older install issues bare
hexadecimal keys, which keep working); do not reject one for looking wrong.
Existing accounts are skipped and their keys are never re-disclosed, so
re-running is safe. A lost key is replaced per account: `POST
/v1/admin/users/<id>/key` (the `id` comes from `GET /v1/admin/users`), or **New
key** on that account's row of the admin page. It returns one new key, once,
and every earlier key of that account stops working; sites and data stay.

**Create in batches of at most 1000, and save each batch before asking for the
next.** Keys are shown once. 5000 accounts is roughly six seconds and 750 KB of
response on a fast machine and several times that on the smallest plan, and a
connection that drops after the server has committed takes every key in that
batch with it — the retry skips the accounts as already existing, so each of
those accounts then needs **New key**. This is about surviving a dropped connection, not
about a limit: create as many as the event needs.

Offer the organiser the list as CSV so they can paste it into a spreadsheet or a
mail merge.

#### 6. Tell participants what to do

Each participant needs two things: their key, and one instruction.

```
Read https://<event-host>/llms.txt and follow it exactly.
My Simple Host API key is: <their key>
Ask me what I want to build, then build it and publish it once I say yes.
```

That works in any agent that can fetch a URL. The instance's own `llms.txt`
names the event's hostnames, not simple-host.app, so their site lands on the
organiser's server.

A participant who only has a chat app (ChatGPT, Claude or Grok in a browser)
adds the event as a connector instead, once: the address is
`https://<event-host>/mcp` — the instance's own, never simple-host.app. The
event's sign-in window opens and, on an instance with no email provider or
Google sign-in, asks for the key the organiser handed out; after **Allow**,
every chat can build and publish to the event. The steps for each chat app are
on the instance's own `https://<event-host>/install.html`. ChatGPT and Grok
allow custom connectors only on paid plans, so mention that to the organiser;
anyone without one uses the prompt above in an agent that can fetch a URL.

#### 7. Collect the entries

Every entry is a link of the form
`https://sites.<event>.<their-domain>/<handle>/<project>/`.

The organiser's admin page lists them. Open `https://<event-host>/admin` and
paste the admin key where it asks ("Sign in with the admin key"); the browser
keeps it. The key is `ADMIN_API_KEY` in `/opt/simple-host/.env` on the box, and
re-running the install command prints it again. Entries shows every published site newest first, filterable, with
the links copyable and downloadable as a spreadsheet. That is the list for the
judges.

This path has no separate entry. One account can hold several sites, so if a
team built more than one, ask which is the entry — the list shows everything
published, not everything submitted.

#### 8. Tear it down

When the event ends, **delete the server and remove both DNS records**. See
`teardown.md` (https://simple-host.app/v1/skills/run-hackathon/references/teardown.md).

Do not skip the DNS records. A record left pointing at a released cloud address
means whoever receives that address next is serving content under that domain
name.

If you claimed free hostnames, release them:

```
DELETE https://simple-host.app/v1/events/<name>?domain=<the domain you claimed>
```

The `domain` must match the claim. Omitting it targets the default domain, which
answers 404 and leaves the real records in place.

If the organiser used their own domain, they delete the two records themselves.

Warn them first: deleting the server destroys every entry. Before you start,
offer to keep a copy of all of them in one archive (every site's files, saved
data and lists; the admin page's "Download all entries" does the same):

```
GET https://<event-host>/v1/admin/export.tar.gz
X-API-Key: <the admin key>
```

Save the response to a file on the organiser's machine and tell them where it is.

### If a site has to come down during the event

A reported or abusive site is taken down without deleting anything, with a
one-line reason the owner sees (the admin page has the same switches):

```
POST https://<event-host>/v1/admin/sites/<site id>/suspend   {"reason": "..."}
POST https://<event-host>/v1/admin/sites/<site id>/restore
POST https://<event-host>/v1/admin/users/<user id>/suspend   {"reason": "..."}
POST https://<event-host>/v1/admin/users/<user id>/enable
```

Ids come from `GET /v1/admin/users`. A taken-down site shows "This site has
been taken down" on every address and refuses changes; a suspended person's key
stops working and all their sites go down. Restore / enable puts it all back.

### What this path does not do

Say these plainly if asked, rather than working around them. They describe the
private instance, not simple-hack.app.

- **No sign-in for participants.** Keys only. Email codes and Google are
  possible on an instance whose domain the organiser controls, but they are
  configured separately and are not part of this flow.
- **Saved data is open.** Anyone who can load a page can change that site's
  stored data. Files change only with the owner's key. If saved data matters for
  judging, have teams copy it before judging starts.
- **No backups.** A disk failure during the event loses the event.
- **Free hostnames expire.** A claim lasts three weeks. Re-claim the same name to
  extend it. After that a sweep removes the records, so a long-running instance
  should use the organiser's own domain.
- **No judging, no rubric, no results page.** The admin page's Entries list is
  what the judges get. Judging, scores and a public winners page are the hosted
  path.
