# The two DNS records

This file is the self-host path: a private Simple Host instance on the organiser's own server. A hosted event on https://simple-hack.app does not use it. That flow is in [SKILL.md](https://simple-host.app/v1/skills/run-hackathon/SKILL.md).

## The easy path: no domain at all

If the organiser has no domain, claim two hostnames under one we run, using
their own Simple Host account key:

```bash
curl -X POST https://simple-host.app/v1/events \
  -H "X-API-Key: <their simple-host.app key>" \
  -H 'Content-Type: application/json' \
  -d '{"name":"stanford-cs-2026","ip":"<server IPv4>","domain":"simple-hack.app"}'
```

Both records are created immediately and the organiser touches nothing. Release them at teardown with
`DELETE /v1/events/<name>?domain=simple-hack.app`. **The domain must match the
claim**; omitting it targets a different one, answers 404, and leaves the real
records in place.

A claim lasts three weeks and re-claiming extends it. Names are lowercased.
Reserved names such as `sites`, `www` and `api` are refused, as are private
addresses, because a public record pointing inside somebody's network would fail
certificate issuance in a way that looks like our bug rather than their typo.

## The other path: their own domain

Both are `A` records pointing at the server's **public IPv4** address.

| Name | Type | Value |
|---|---|---|
| `<event>` | A | the server's IPv4 |
| `sites.<event>` | A | the same IPv4 |

For an event called `builds` on `example.com`, that is `builds.example.com` and
`sites.builds.example.com`.

Use a short TTL, 60 to 300 seconds, so teardown takes effect quickly.

## The wildcard will lie to you for half an hour

The domain that hands out free hostnames carries a wildcard record with a
**30-minute lifetime**, while event records use two minutes. Any resolver that
looked up the name *before* the claim keeps serving the wildcard until that
expires.

What that looks like: `https://<event>/healthz` returns **404 behind a valid
certificate**, because you reached the wildcard's host and it holds a real
certificate for the domain. It looks exactly like a failed install of a working
instance. Both walkthroughs of this skill lost time to it.

Check against a public resolver rather than your own, and compare:

```bash
dig +short <event>.<domain> A @1.1.1.1
dig +short <event>.<domain> A @8.8.8.8
```

If those show the server and your own machine disagrees, the instance is fine
and your resolver is stale. Say so to the organiser rather than debugging the
server.

## Wait for them before installing

```bash
dig +short builds.example.com A
dig +short sites.builds.example.com A
```

Both must return the server's address. Installing early works, but certificate
issuance fails and the organiser sees browser warnings, which is far more
alarming than waiting.

## Per registrar

The organiser adds these themselves; you cannot, and should not ask for their
registrar password.

- **Vercel.** Domains, pick the domain, add a record. Name is the subdomain
  only, not the full hostname.
- **Cloudflare.** DNS, add record. **Turn the proxy off, grey cloud not orange.**
  Proxied records break certificate issuance for this setup and hide the real IP
  from Let's Encrypt.
- **GoDaddy.** DNS, Manage Zones, add. Name is the subdomain only.
- **Porkbun.** Details, DNS records. Type A, host is the subdomain only.
- **Namecheap.** Advanced DNS, Add New Record, A Record.

The same guidance in more depth lives in the `connect-domain` skill's
`references/registrars.md`.
